const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const { DynamoDBDocumentClient, UpdateCommand } = require("@aws-sdk/lib-dynamodb");
const { SNSClient, PublishCommand } = require("@aws-sdk/client-sns");

const ddb = DynamoDBDocumentClient.from(new DynamoDBClient({}));
const sns = new SNSClient({});

const TABLE = process.env.AGG_TABLE;
const TOPIC = process.env.SNS_TOPIC_ARN;

/* ============ SINGLE-PASS AGGREGATION ============ */

function aggregateEvents(records) {
  const aggregations = {
    countsByMinute: {},
    categoryAgg: {},
    campaignAgg: {},
    deviceAgg: {},
    segmentAgg: {},
    cityAgg: {},
    ageAgg: {},
    anomalies: []
  };

  for (const e of records) {
    const minute = e.timestamp.slice(0, 16);

    // 1. Timeline aggregations
    if (!aggregations.countsByMinute[minute]) {
      aggregations.countsByMinute[minute] = { total: 0, orders: 0, revenue: 0 };
    }
    aggregations.countsByMinute[minute].total += 1;
    aggregations.countsByMinute[minute][e.eventType] =
      (aggregations.countsByMinute[minute][e.eventType] || 0) + 1;
    
    if (e.eventType === 'order') {
      aggregations.countsByMinute[minute].orders += 1;
      aggregations.countsByMinute[minute].revenue = 
        (aggregations.countsByMinute[minute].revenue || 0) + (e.orderValue || 0);
    }

    // 2. Category aggregations
    const catKey = `cat#${e.productCategory}`;
    if (!aggregations.categoryAgg[catKey]) {
      aggregations.categoryAgg[catKey] = { total: 0, orders: 0, revenue: 0 };
    }
    aggregations.categoryAgg[catKey].total += 1;
    aggregations.categoryAgg[catKey][e.eventType] =
      (aggregations.categoryAgg[catKey][e.eventType] || 0) + 1;
    if (e.eventType === 'order' && !e.isAnomaly) {
      aggregations.categoryAgg[catKey].orders += 1;
      aggregations.categoryAgg[catKey].revenue = 
        (aggregations.categoryAgg[catKey].revenue || 0) + (e.orderValue || 0);
    }

    // 3. Campaign aggregations
    const campaignKey = `campaign#${e.campaignId}`;
    if (!aggregations.campaignAgg[campaignKey]) {
      aggregations.campaignAgg[campaignKey] = { total: 0, orders: 0, revenue: 0 };
    }
    aggregations.campaignAgg[campaignKey].total += 1;
    if (e.eventType === 'order' && !e.isAnomaly) {
      aggregations.campaignAgg[campaignKey].orders += 1;
      aggregations.campaignAgg[campaignKey].revenue = 
        (aggregations.campaignAgg[campaignKey].revenue || 0) + (e.orderValue || 0);
    }

    // 4. Device aggregations
    const deviceKey = `device#${e.deviceType}`;
    if (!aggregations.deviceAgg[deviceKey]) {
      aggregations.deviceAgg[deviceKey] = { total: 0, orders: 0 };
    }
    aggregations.deviceAgg[deviceKey].total += 1;
    if (e.eventType === 'order') {
      aggregations.deviceAgg[deviceKey].orders += 1;
    }

    // 5. Segment aggregations
    const segmentKey = `segment#${e.segment}`;
    if (!aggregations.segmentAgg[segmentKey]) {
      aggregations.segmentAgg[segmentKey] = { total: 0, orders: 0, revenue: 0 };
    }
    aggregations.segmentAgg[segmentKey].total += 1;
    if (e.eventType === 'order' && !e.isAnomaly) {
      aggregations.segmentAgg[segmentKey].orders += 1;
      aggregations.segmentAgg[segmentKey].revenue = 
        (aggregations.segmentAgg[segmentKey].revenue || 0) + (e.orderValue || 0);
    }

    // 6. City aggregations
    const cityKey = `city#${e.city}`;
    if (!aggregations.cityAgg[cityKey]) {
      aggregations.cityAgg[cityKey] = { total: 0, orders: 0 };
    }
    aggregations.cityAgg[cityKey].total += 1;
    if (e.eventType === 'order') {
      aggregations.cityAgg[cityKey].orders += 1;
    }

    // 7. Age group aggregations
    if (e.ageGroup) {
      const ageKey = `age#${e.ageGroup}`;
      if (!aggregations.ageAgg[ageKey]) {
        aggregations.ageAgg[ageKey] = { total: 0, orders: 0, revenue: 0 };
      }
      aggregations.ageAgg[ageKey].total += 1;
      aggregations.ageAgg[ageKey][e.eventType] =
        (aggregations.ageAgg[ageKey][e.eventType] || 0) + 1;
      if (e.eventType === 'order' && !e.isAnomaly) {
        aggregations.ageAgg[ageKey].orders += 1;
        aggregations.ageAgg[ageKey].revenue =
          (aggregations.ageAgg[ageKey].revenue || 0) + (e.orderValue || 0);
      }
    }

    // 8. Anomaly tracking
    if (e.isAnomaly) {
      aggregations.anomalies.push({
        eventId: e.eventId,
        type: e.anomalyType,
        category: e.productCategory,
        timestamp: e.timestamp
      });
    }
  }

  return aggregations;
}

/* ============ DYNAMODB UPDATES ============ */

async function updateDynamoDB(aggregations) {
  const updates = [];

  // Update timeline metrics
  for (const [minute, counts] of Object.entries(aggregations.countsByMinute)) {
    const exprNames = { "#total": "total", "#lastSeen": "lastSeen" };
    const exprValues = { ":t": counts.total, ":ts": minute + ":00Z" };
    const addParts = ["#total :t"];

    if (counts.orders > 0) {
      exprNames["#orders"] = "orders";
      exprValues[":orders"] = counts.orders;
      addParts.push("#orders :orders");
    }

    if (counts.revenue > 0) {
      exprNames["#revenue"] = "revenue";
      exprValues[":revenue"] = counts.revenue;
      addParts.push("#revenue :revenue");
    }

    let idx = 0;
    for (const [type, count] of Object.entries(counts)) {
      if (["total", "orders", "revenue"].includes(type)) continue;
      idx++;
      exprNames[`#e${idx}`] = type;
      exprValues[`:v${idx}`] = count;
      addParts.push(`#e${idx} :v${idx}`);
    }

    updates.push(
      ddb.send(new UpdateCommand({
        TableName: TABLE,
        Key: { id: `live#${minute}` },
        UpdateExpression: `ADD ${addParts.join(", ")} SET #lastSeen = :ts`,
        ExpressionAttributeNames: exprNames,
        ExpressionAttributeValues: exprValues
      }))
    );
  }

  // Update dimension metrics
  const allDimensions = {
    ...aggregations.categoryAgg,
    ...aggregations.campaignAgg,
    ...aggregations.deviceAgg,
    ...aggregations.segmentAgg,
    ...aggregations.cityAgg,
    ...aggregations.ageAgg
  };

  for (const [id, counts] of Object.entries(allDimensions)) {
    const exprNames = {};
    const exprValues = {};
    const addParts = [];

    let idx = 0;
    for (const [key, val] of Object.entries(counts)) {
      if (typeof val !== 'number' || val <= 0) continue;
      exprNames[`#f${idx}`] = key;
      exprValues[`:v${idx}`] = val;
      addParts.push(`#f${idx} :v${idx}`);
      idx++;
    }

    if (addParts.length > 0) {
      updates.push(
        ddb.send(new UpdateCommand({
          TableName: TABLE,
          Key: { id },
          UpdateExpression: `ADD ${addParts.join(", ")}`,
          ExpressionAttributeNames: exprNames,
          ExpressionAttributeValues: exprValues
        }))
      );
    }
  }

  await Promise.all(updates);
}

/* ============ SNS NOTIFICATIONS ============ */

async function notifyAnomalies(anomalies) {
  if (!TOPIC || anomalies.length === 0) return;

  const message = {
    timestamp: new Date().toISOString(),
    totalAnomalies: anomalies.length,
    byType: {},
    events: anomalies
  };

  for (const anomaly of anomalies) {
    message.byType[anomaly.type] = (message.byType[anomaly.type] || 0) + 1;
  }

  await sns.send(new PublishCommand({
    TopicArn: TOPIC,
    Subject: `🚨 Anomaly Alert: ${anomalies.length} anomalies detected`,
    Message: JSON.stringify(message, null, 2)
  }));
}

/* ============ HANDLER ============ */

exports.handler = async (event) => {
  console.log(`📥 Processing ${event.Records.length} Kinesis records`);

  try {
    // Decode Kinesis records
    const records = event.Records
      .map(r => JSON.parse(Buffer.from(r.kinesis.data, "base64").toString()))
      .filter(r => r); // Remove any null records

    if (records.length === 0) {
      console.log("⚠️  No valid records to process");
      return { statusCode: 200, processedRecords: 0 };
    }

    // Single-pass aggregation
    const aggregations = aggregateEvents(records);

    // Update DynamoDB
    await updateDynamoDB(aggregations);
    console.log(`✅ Updated ${Object.keys(aggregations.countsByMinute).length} timeline entries`);

    // Handle anomalies
    if (aggregations.anomalies.length > 0) {
      console.log(`🚨 Found ${aggregations.anomalies.length} anomalies`);
      await notifyAnomalies(aggregations.anomalies);
    }

    return {
      statusCode: 200,
      processedRecords: records.length,
      anomaliesDetected: aggregations.anomalies.length,
      dimensionsUpdated: Object.keys(aggregations.categoryAgg).length +
                         Object.keys(aggregations.campaignAgg).length +
                         Object.keys(aggregations.segmentAgg).length
    };
  } catch (err) {
    console.error("❌ Processing error:", err);
    throw err;
  }
};