const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const { DynamoDBDocumentClient, ScanCommand } = require("@aws-sdk/lib-dynamodb");

const ddb = DynamoDBDocumentClient.from(new DynamoDBClient({}));
const TABLE = process.env.AGG_TABLE;

// In-memory cache — persists across warm Lambda invocations within the same container.
// TTL of 15 s: dashboard polls every 3 s, so this cuts DynamoDB Scan calls by ~80 %.
const CACHE_TTL_MS = 15_000;
let cachedMetrics = null;
let cacheExpiresAt = 0;

/**
 * Parse flat DynamoDB items into dashboard metrics.
 * Item schema written by stream.js:
 *   live#YYYY-MM-DDTHH:mm  → { total, page_view, product_view, add_to_cart, order, orders, revenue }
 *   cat#<name>             → { total, orders, revenue, page_view, product_view, add_to_cart, order }
 *   campaign#<id>          → { total, orders, revenue }
 *   city#<city>            → { total, orders, revenue }
 *   age#<group>            → { total, orders, revenue }
 *   segment#<seg>          → { total, orders, revenue }
 *   device#<type>          → { total, orders }
 */
function parseItems(items = []) {
  const metrics = {
    totalEvents: 0,
    dataPoints: 0,
    eventsByType: { page_view: 0, product_view: 0, add_to_cart: 0, order: 0 },
    recentMinutes: [],
    categoryStats: {},
    campaignStats: {},
    geoStats: {},
    ageStats: {},
    revenueStats: { total_revenue: 0, order_count: 0, avg_order_value: 0 }
  };

  for (const item of items) {
    const id = item.id || "";

    if (id.startsWith("live#")) {
      const total = Number(item.total) || 0;
      metrics.totalEvents += total;
      metrics.dataPoints += 1;
      metrics.eventsByType.page_view    += Number(item.page_view)    || 0;
      metrics.eventsByType.product_view += Number(item.product_view) || 0;
      metrics.eventsByType.add_to_cart  += Number(item.add_to_cart)  || 0;
      metrics.eventsByType.order        += Number(item.order)        || 0;
      metrics.revenueStats.total_revenue += Number(item.revenue)     || 0;
      metrics.revenueStats.order_count   += Number(item.orders)      || 0;
      metrics.recentMinutes.push({
        id,
        total,
        page_view:    Number(item.page_view)    || 0,
        product_view: Number(item.product_view) || 0,
        add_to_cart:  Number(item.add_to_cart)  || 0,
        order:        Number(item.order)        || 0,
        lastSeen:     item.lastSeen || null
      });
    } else if (id.startsWith("cat#")) {
      const name = id.replace("cat#", "");
      metrics.categoryStats[name] = {
        total:        Number(item.total)        || 0,
        orders:       Number(item.orders)       || 0,
        revenue:      Number(item.revenue)      || 0,
        page_view:    Number(item.page_view)    || 0,
        product_view: Number(item.product_view) || 0,
        add_to_cart:  Number(item.add_to_cart)  || 0,
        order:        Number(item.order)        || 0
      };
    } else if (id.startsWith("campaign#")) {
      const name = id.replace("campaign#", "");
      metrics.campaignStats[name] = {
        total:       Number(item.total)   || 0,
        order_count: Number(item.orders)  || 0,
        revenue:     Number(item.revenue) || 0
      };
    } else if (id.startsWith("city#")) {
      const name = id.replace("city#", "");
      metrics.geoStats[name] = {
        total:       Number(item.total)   || 0,
        order_count: Number(item.orders)  || 0,
        revenue:     Number(item.revenue) || 0
      };
    } else if (id.startsWith("age#")) {
      const name = id.replace("age#", "");
      metrics.ageStats[name] = {
        total:        Number(item.total)        || 0,
        order_count:  Number(item.orders)       || 0,
        revenue:      Number(item.revenue)      || 0,
        page_view:    Number(item.page_view)    || 0,
        product_view: Number(item.product_view) || 0,
        add_to_cart:  Number(item.add_to_cart)  || 0,
        order:        Number(item.order)        || 0
      };
    }
  }

  if (metrics.revenueStats.order_count > 0) {
    metrics.revenueStats.avg_order_value = Math.round(
      metrics.revenueStats.total_revenue / metrics.revenueStats.order_count
    );
  }

  // Sort most-recent first, keep last 30 minutes
  metrics.recentMinutes = metrics.recentMinutes
    .sort((a, b) => b.id.localeCompare(a.id))
    .slice(0, 30);

  return metrics;
}

exports.handler = async () => {
  const now = Date.now();

  // Return cached result if still fresh
  if (cachedMetrics && now < cacheExpiresAt) {
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type",
        "X-Cache": "HIT"
      },
      body: cachedMetrics
    };
  }

  try {
    const result = await ddb.send(new ScanCommand({
      TableName: TABLE,
      Limit: 200
    }));

    const metrics = parseItems(result.Items || []);
    cachedMetrics = JSON.stringify(metrics);
    cacheExpiresAt = now + CACHE_TTL_MS;

    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type",
        "X-Cache": "MISS"
      },
      body: cachedMetrics
    };
  } catch (err) {
    console.error("Error fetching metrics:", err);
    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({ error: err.message })
    };
  }
};
